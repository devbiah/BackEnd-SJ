for(var i=10; i>0;i--){
    console.log(i)
}