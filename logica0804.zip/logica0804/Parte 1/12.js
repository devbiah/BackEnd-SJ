lista = [5, 12, 4, 55, 2]

menor = 0
maior = 0
for (i in lista)
    if (i == 0) {
        maior = lista[i]
        menor = lista[i]
    }
    else {
        if (lista[i] > maior) {
            maior = lista[i]
        }
        if (lista[i] < menor) {
            menor = lista[i]
        }
    }
console.log(`O maior nº é: ${maior}\nO menor nº é: ${menor}`)