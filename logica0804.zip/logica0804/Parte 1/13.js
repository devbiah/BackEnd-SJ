var n = [5, 12, 4, 55, 2];
var soma = 0;
for (var i = 0; i < n.length; i++) {
    soma += n[i];
}
var media = soma / n.length;
console.log(`A média dos elementos é: ${media}`);