result = 1
for (var i = 1; i < 10; i++)
    result += (1 / i)
console.log(result)