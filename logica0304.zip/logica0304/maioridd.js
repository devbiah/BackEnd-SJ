idade = 0

while(idade<18){
idade = prompt("Digite uma idade: ")
}

alert ("Você é maior de 18")