///Laço de repetição (Loop)

///While(Enquanto)
var contador = 0	///inteiro
while (contador<10){
	alert("Loop")
	contador++ 	///contador+1 
}

///variavel++ (incremento)=> +1
///variavel-- (decremento)=> -1
///variavel+=2 (qualquer número que quiser somar, pode ser 2,3,4,5,6… qual número quiser)
