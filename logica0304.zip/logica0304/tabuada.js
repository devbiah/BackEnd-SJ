var n = prompt("Digite um número para fazer a tabuada: ")
var mult = 0
for(i=1;i<=10;i++){
    mult = n*i
    console.log(mult)
}