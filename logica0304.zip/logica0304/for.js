for (var i = 1; i <= 100; i *= 4) {
    console.log(i) //i+=2 => i=i+2 //i*=2 => o número elevado a ele mesmo,
//exemplo: o numero começa com 0 e vai multiplicando por 4 ficaria: 4x4=16x4=64
// for(var i = 0; i<=100; i++){
//     console.log(i)
// } ///do 1 ao 100
// //for(var i = 99; i>=0; i--){
//    console.log(i)
//} //do 99 até o 0
}


