for (var i = 1; i <= 100; i++) {
    if (i % 2 == 0)
        console.log(`Par ${i}`)
    else
        console.log(`Ímpar ${i}`)
}