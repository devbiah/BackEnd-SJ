var n = 2
var vezes = 0

for (var i = 1; i <= n; i++) {
    if (n % i == 0) {
        vezes++
    }
}
if (vezes == 2)
    console.log(`Ele é primo: ${n}`)
else
    console.log(`Não é primo: ${n}`)