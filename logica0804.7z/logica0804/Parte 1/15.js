for (var n = 1; n <= 50; n++) {
    var vezes = 0

    for (var i = 1; i <= n; i++) {
        if (n % i == 0) {
            vezes++
        }
    }
    if (vezes == 2)
        console.log(n)
}