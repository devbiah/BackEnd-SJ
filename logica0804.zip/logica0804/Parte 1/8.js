for (var i = f; i > 1; i--) {
    r *= i;
    var f = 5;
    var r = 1;
}
console.log(r);