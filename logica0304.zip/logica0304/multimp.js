for(var i=100;i<=200;i++){
    if(i%3==0 && i%2!=0){
        console.log(i)
    }
}