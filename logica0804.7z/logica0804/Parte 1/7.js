for (var i = 1; i < 10; i++) {
    console.log(i)
}

for (var i = 10; i > 0; i--) {
    console.log(i)
}