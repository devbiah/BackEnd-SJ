soma = 0
for(var i = 10; i <= 20; i++){
    soma += i

}

console.log(soma)