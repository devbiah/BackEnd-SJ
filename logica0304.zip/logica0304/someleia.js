total = 0

for(var i = 0; i < 5; i++){
    n = Number(prompt("Digite um nº para a soma: "))    
    if(n>7){
    total += n
    }
}
alert(total)