var n1 = 1

while (n1 <= 201){
    if(n1 % 2 === 0)
        console.log(n1)
    n1++
}
