n = Number(prompt(`Digite um número para a tabuada: `))

for(var i=0; i<=10;i++){
    console.log(`${n} x ${i}=${n*i}`)
}
